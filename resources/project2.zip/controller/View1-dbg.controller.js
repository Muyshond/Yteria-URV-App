"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace project2.controller
   */
  const View1 = Controller.extend("project2.controller.View1", {
    /*eslint-disable @typescript-eslint/no-empty-function*/onInit: function _onInit() {},
    getRoleCollections: async function _getRoleCollections() {
      try {
        const response = await fetch("/odata/v4/catalog/getRoleCollections");
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
        return data;
      } catch (error) {
        console.error("Error:", error);
      }
    }
  });
  return View1;
});
//# sourceMappingURL=View1-dbg.controller.js.map
