import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace project2.controller
 */
export default class App extends Controller {

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {

    }
}