//@ui5-bundle captest/Component-preload.js
sap.ui.require.preload({
	"captest/Component.js":function(){
"use strict";sap.ui.define(["sap/ui/core/UIComponent","./model/models"],function(e,t){"use strict";const i=t["createDeviceModel"];const n=e.extend("captest.Component",{metadata:{manifest:"json",interfaces:["sap.ui.core.IAsyncContentCreation"]},init:function t(){e.prototype.init.call(this);this.setModel(i(),"device");this.getRouter().initialize()}});return n});
},
	"captest/controller/App.controller.js":function(){
"use strict";sap.ui.define(["sap/ui/core/mvc/Controller"],function(t){"use strict";const n=t.extend("captest.controller.App",{onInit:function t(){}});return n});
},
	"captest/controller/View1.controller.js":function(){
"use strict";sap.ui.define(["sap/ui/core/mvc/Controller"],function(o){"use strict";const t=o.extend("captest.controller.View1",{onInit:function o(){},getRoleCollections:async function o(){try{const o=await fetch("/Ypto-URV-Application-srv-api/getRoleCollections");if(!o.ok){throw new Error(`Error: ${o.status}`)}const t=await o.json();console.log(t);return t}catch(o){console.error("Error:",o)}}});return t});
},
	"captest/i18n/i18n.properties":'# This is the resource bundle for captest\n\n#Texts for manifest.json\n\n#XTIT: Application name\nappTitle=App Title\n\n#YDES: Application description\nappDescription=An SAP Fiori application.\n#XTIT: Main view title\ntitle=App Title',
	"captest/manifest.json":'{"_version":"1.65.0","sap.app":{"id":"captest","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"0.0.1"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","sourceTemplate":{"id":"@sap/generator-fiori:basic","version":"1.16.5","toolsId":"02b81562-d1ab-4240-bb13-a5fcd0cbb009"},"dataSources":{"mainService":{"uri":"odata/v4/catalog/","type":"OData","settings":{"annotations":[],"odataVersion":"4.0"}}}},"sap.ui":{"technology":"UI5","icons":{"icon":"","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":true,"dependencies":{"minUI5Version":"1.133.0","libs":{"sap.m":{},"sap.ui.core":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"captest.i18n.i18n"}},"":{"dataSource":"mainService","preload":true,"settings":{"operationMode":"Server","autoExpandSelect":true,"earlyRequests":true}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","controlAggregation":"pages","controlId":"app","transition":"slide","type":"View","viewType":"XML","path":"captest.view"},"routes":[{"name":"RouteView1","pattern":":?query:","target":["TargetView1"]}],"targets":{"TargetView1":{"id":"View1","name":"View1"}}},"rootView":{"viewName":"captest.view.App","type":"XML","id":"App"}},"sap.cloud":{"public":true,"service":"urv-app"}}',
	"captest/model/models.js":function(){
"use strict";sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";function t(){const t=new e(n);t.setDefaultBindingMode("OneWay");return t}var i={__esModule:true};i.createDeviceModel=t;return i});
},
	"captest/view/App.view.xml":'<mvc:View controllerName="captest.controller.App"\n    displayBlock="true"\n    xmlns:mvc="sap.ui.core.mvc"\n    xmlns="sap.m"><App id="app"></App></mvc:View>',
	"captest/view/View1.view.xml":'<mvc:View controllerName="captest.controller.View1"\n    xmlns:mvc="sap.ui.core.mvc"\n    xmlns="sap.m"><Page id="page" title="{i18n>title}"><Button id="userButton" text="Get User Info" type="Emphasized" press="getRoleCollections"></Button></Page></mvc:View>'
});
//# sourceMappingURL=Component-preload.js.map
