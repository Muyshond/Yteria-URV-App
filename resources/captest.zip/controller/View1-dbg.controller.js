"use strict";

sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
  "use strict";

  /**
   * @namespace captest.controller
   */
  const View1 = Controller.extend("captest.controller.View1", {
    /*eslint-disable @typescript-eslint/no-empty-function*/onInit: function _onInit() {},
    getRoleCollections: async function _getRoleCollections() {
      try {
        const response = await fetch("/Ypto-URV-Application-srv-api/getRoleCollections");
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
        const data = await response.json();
        console.log(data);
        return data;
      } catch (error) {
        console.error("Error:", error);
      }
    }
  });
  return View1;
});
//# sourceMappingURL=View1-dbg.controller.js.map
