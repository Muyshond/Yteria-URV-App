"use strict";

sap.ui.define([], function () {
  "use strict";

  // /model/MyService.ts

  class testService {
    static testfunction() {
      return "test hsjldlmqHDFJKLMSQDHJFKQSLH";
    }
  }
  return testService;
});
//# sourceMappingURL=testService-dbg.js.map
