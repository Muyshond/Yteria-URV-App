"use strict";sap.ui.define([],function(){"use strict";function t(t){return"test"}return{functiontest:t}});
//# sourceMappingURL=dataService.js.map