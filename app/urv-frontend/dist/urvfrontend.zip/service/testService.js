"use strict";sap.ui.define([],function(){"use strict";class t{static testfunction(){return"test hsjldlmqHDFJKLMSQDHJFKQSLH"}}return t});
//# sourceMappingURL=testService.js.map