// /model/MyService.ts
import { ODataModel } from "sap/ui/model/odata/v2/ODataModel";

export default class testService {
  static testfunction(): String {
    return "test hsjldlmqHDFJKLMSQDHJFKQSLH"
  }



  
}