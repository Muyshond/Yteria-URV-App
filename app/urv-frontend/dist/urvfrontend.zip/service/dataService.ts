sap.ui.define([], function () {
    "use strict";

    function functiontest(oView): string {
        return "test";
    }

    return {
        functiontest
    };
});