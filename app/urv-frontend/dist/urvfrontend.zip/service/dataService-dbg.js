"use strict";

sap.ui.define([], function () {
  "use strict";

  function functiontest(oView) {
    return "test";
  }
  return {
    functiontest
  };
});
//# sourceMappingURL=dataService-dbg.js.map
